Author: 		KeenThemes
Website: 		http://www.keenthemes.com/
Contact: 		support@keenthemes.com
Follow: 		http://twitter.com/keenthemes
Like: 			http://facebook.com/keenthemes

Looking for a perfect premium bootstrap admin theme for your project ? You got to check Metronic, our #1 selling admin theme in the market: 
http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes

Happy coding!  Don't miss a stuff from us - http://twitter.com/keenthemes