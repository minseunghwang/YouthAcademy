========================

Gumba Website Template

0.1.0

========================

Author
Rick Waalders

Twitter
http://twitter.com/rickwaalders

Website
http://www.pixelsbyrick.com

========================

Help

- If you want to enable the navigation, uncomment and change the <nav> element inside index.html
- There's a placeholder for Google Analytics. If you have a GA account, just paste your tracking ID at 'YOUR_GOOGLE_ANALYTICS_ID'.

========================

License

- Please refer to the LICENSE.md file

========================

This projects uses open-source components:

jQuery - http://jquery.com/
Fluidbox - http://terrymun.github.io/Fluidbox/
Bourbon - http://bourbon.io/
Neat - http://neat.bourbon.io/
Photos - http://unsplash.com / http://www.pexels.com
