======

LICENSE

======

I prefer using plain english in licenses (and any other contract for that matter), so here is a ReallySimpleLicense. 
All templates on the website www.pixelsbyrick.com like the current template you've downloaded, come with this ReallySimpleLicense.

This ReallySimpleLicense allows you to use this item in personal and commercial projects, but it cannot be resold or redistributed on its own without my knowledge. You also cannot use the item inside another item that you're selling.

Some parts of the template are covered by Open Source licenses such as the MIT license and GPL. All other parts that have been written by me are covered by this ReallySimpleLicense.

If you are in doubt or have any questions regarding what you can and what you cannot do, please don't hesitate to contact me:

http://twitter.com/rickwaalders
rwaalders@gmail.com

======

The Gumba template is powered by the following open source components:

jQuery - http://jquery.com/
Fluidbox - http://terrymun.github.io/Fluidbox/
Bourbon - http://bourbon.io/
Neat - http://neat.bourbon.io/
Photos - http://unsplash.com / http://www.pexels.com

Please respect the licenses of those components when using this template too, next to the ReallySimpleLicense above for all other code that has been written by me.

======
